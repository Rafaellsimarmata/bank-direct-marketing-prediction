import tensorflow as tf
import tensorflow_transform as tft

LABEL_KEY = "y"

CATEGORICAL_FEATURE_KEYS = {
    'job': 12,
    'marital': 4,
    'education': 8,
    'default': 3,
    'housing': 3,
    'loan': 3,
    'contact': 2,
    'month': 10,
    'day_of_week': 5,
    'poutcome': 3
}

INT_FEATURE_KEYS = ['age', 'campaign', 'pdays', 'previous']
FLOAT_FEATURE_KEYS = ['emp.var.rate', 'cons.price.idx', 'cons.conf.idx', 'euribor3m', 'nr.employed']

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def one_hot_encoding(indices, num_label):
    one_hot = tf.one_hot(indices, num_label) 
    return tf.reshape(one_hot, (-1, num_label)) 

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features
    
    Args:
        inputs: map from feature keys to raw features.
    
    Returns:
        outputs: map from feature keys to transformed features.    
    """
    outputs = {}
        
    # Process categorical features
    for key, value in CATEGORICAL_FEATURE_KEYS.items():
        integerized = tft.compute_and_apply_vocabulary(inputs[key], top_k = value+1)
        outputs[transformed_name(key)] = one_hot_encoding(integerized, value + 1)

    # Standardize numerical features
    for key in INT_FEATURE_KEYS:
        value = tf.cast(inputs[key], tf.int64)
        outputs[transformed_name(key)] = tft.scale_to_z_score(value)

    for key in FLOAT_FEATURE_KEYS:
        value = tf.cast(inputs[key], tf.float32)
        outputs[transformed_name(key)] = tft.scale_to_z_score(value)


    integerized = tft.compute_and_apply_vocabulary(inputs[LABEL_KEY], top_k = 3)
    outputs[transformed_name(LABEL_KEY)] = one_hot_encoding(integerized, 3)
    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)
    
    return outputs
